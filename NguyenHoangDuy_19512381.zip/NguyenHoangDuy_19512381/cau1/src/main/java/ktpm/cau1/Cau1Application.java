package ktpm.cau1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cau1Application {

	public static void main(String[] args) {
		SpringApplication.run(Cau1Application.class, args);
	}

}
