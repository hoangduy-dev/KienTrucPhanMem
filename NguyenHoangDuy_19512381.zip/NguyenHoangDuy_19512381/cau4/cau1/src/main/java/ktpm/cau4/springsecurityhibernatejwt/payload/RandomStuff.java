package ktpm.cau4.springsecurityhibernatejwt.payload;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class RandomStuff {
    private String message;
}
