package ktpm.cau1.model;

import lombok.Data;

@Data
public class OrderDto {
	private String name;
	private double price;
}
